QUVIYO — GitHub Pages publishing

Files:
- index.html
- style.css
- script.js
- config.js

IMPORTANT:
The API key in config.js has been replaced with YOUR_YOUTUBE_DATA_API_V3_KEY
to avoid publishing a key accidentally.

Before publishing:
1. In Google Cloud Console, open APIs & Services > Credentials.
2. Configure the key to allow YouTube Data API v3 only.
3. Add an HTTP referrer restriction for your final GitHub Pages URL, for example:
   https://YOUR-GITHUB-USERNAME.github.io/*
   For a project site you can use the more specific path:
   https://YOUR-GITHUB-USERNAME.github.io/Quviyo/*
   Include any localhost referrer you need for local development.
4. Edit config.js in the GitHub repository and replace YOUR_YOUTUBE_DATA_API_V3_KEY
   with your restricted key.
5. Do not paste the key into public issues or chat.

GitHub Pages:
- Upload these files at the repository root (not inside a nested YOUTUBE-REA folder).
- Settings > Pages > Deploy from a branch > main > /(root) > Save.
