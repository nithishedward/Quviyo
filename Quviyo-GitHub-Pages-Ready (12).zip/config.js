// Replace this placeholder with your YouTube Data API v3 key.
window.YOUTUBE_API_KEY = "YOUR_YOUTUBE_DATA_API_V3_KEY";
